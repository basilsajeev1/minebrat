import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApisService {

  constructor(private http: HttpClient) { }

  getStates(){
    return this.http.get('http://api.minebrat.com/api/v1/states')
  }

  getCities(id:any){
    return this.http.get(`http://api.minebrat.com/api/v1/states/cities/${id}`)
  }
}
