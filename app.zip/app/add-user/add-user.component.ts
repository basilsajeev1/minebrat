import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl , FormBuilder, FormArray} from '@angular/forms';
import { ApisService } from '../apis.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit{

  userForm = this.fb.group({
    firstName: [''],
    lastName: [''],
    age: [''],
    profile: [''],
    line1:[''],
    line2:[''],
    state:[''],
    city:[''],
    country:['India'],
    experience: this.fb.array([this.createExperience() ]), 
    education: this.fb.array([ this.createeducation()  ]),
    
})

statesList:any=[]; cityList:any = [];
dropdownSettings: IDropdownSettings = {};

  constructor(private fb: FormBuilder, private api: ApisService) {
    
  }
  ngOnInit(): void {
    // this.api.getStates().subscribe((result)=>{
    //   this.statesList = result
    // })

    this.statesList = [
      {
          "stateId": "1",
          "stateName": "Delhi",
          "city": [
              {
                  "cityId": "1",
                  "cityName": "South east delhi"
              },
              {
                  "cityId": "3",
                  "cityName": "North west delhi"
              },
              {
                  "cityId": "4",
                  "cityName": "West delhi"
              },
              {
                  "cityId": "2",
                  "cityName": "North delhi"
              },
              {
                  "cityId": "5",
                  "cityName": "Central delhi"
              }
          ]
      },
      {
          "stateId": "10",
          "stateName": "Gujarat",
          "city": [
              {
                  "cityId": "212",
                  "cityName": "Dahod"
              },
              {
                  "cityId": "197",
                  "cityName": "Porbandar"
              },
              {
                  "cityId": "210",
                  "cityName": "Panch mahals"
              },
              {
                  "cityId": "217",
                  "cityName": "Navsari"
              },
              {
                  "cityId": "211",
                  "cityName": "Vadodara"
              },
              {
                  "cityId": "214",
                  "cityName": "Bharuch"
              },
              {
                  "cityId": "198",
                  "cityName": "Junagadh"
              },
              {
                  "cityId": "207",
                  "cityName": "Banaskantha"
              },
              {
                  "cityId": "196",
                  "cityName": "Surendra nagar"
              },
              {
                  "cityId": "213",
                  "cityName": "Narmada"
              },
              {
                  "cityId": "205",
                  "cityName": "Sabarkantha"
              },
              {
                  "cityId": "192",
                  "cityName": "Rajkot"
              },
              {
                  "cityId": "201",
                  "cityName": "Ahmedabad"
              },
              {
                  "cityId": "204",
                  "cityName": "Mahesana"
              },
              {
                  "cityId": "215",
                  "cityName": "Surat"
              },
              {
                  "cityId": "202",
                  "cityName": "Morbi"
              },
              {
                  "cityId": "203",
                  "cityName": "Kachchh"
              },
              {
                  "cityId": "209",
                  "cityName": "Anand"
              },
              {
                  "cityId": "194",
                  "cityName": "Bhavnagar"
              },
              {
                  "cityId": "195",
                  "cityName": "Amreli"
              },
              {
                  "cityId": "206",
                  "cityName": "Patan"
              },
              {
                  "cityId": "193",
                  "cityName": "Jamnagar"
              },
              {
                  "cityId": "218",
                  "cityName": "Valsad"
              },
              {
                  "cityId": "216",
                  "cityName": "The dangs"
              },
              {
                  "cityId": "208",
                  "cityName": "Kheda"
              },
              {
                  "cityId": "200",
                  "cityName": "Gandhi nagar"
              }
          ]
      },
    ]

    this.dropdownSettings = {
      singleSelection: false,
      idField: 'cityId',
      textField: 'cityName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  }

  getCities(){
    // this.api.getCities(this.userForm.value.state).subscribe((result)=>{
    //   this.cityList = result
    // })
    this.cityList = [
      {
          "cityId": "1",
          "cityName": "South east delhi"
      },
      {
          "cityId": "2",
          "cityName": "North delhi"
      },
      {
          "cityId": "3",
          "cityName": "North west delhi"
      },
      {
          "cityId": "4",
          "cityName": "West delhi"
      },
      {
          "cityId": "5",
          "cityName": "Central delhi"
      }
  ]
  }


  onSubmit(){

    console.log("value", this.userForm.value)
    let res = JSON.stringify(this.userForm.value) 
    const file = new Blob([res], { type: '.txt' });
    var a = document.createElement("a"),
                url = URL.createObjectURL(file);
        a.href = url;
        a.download = "user_detail";
        document.body.appendChild(a);
        a.click();
        setTimeout(function() {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);  
        }, 0); 
  }

  createExperience(): FormGroup {
    return this.fb.group({
      company: '',
      role: '',
      years: ''
    });
  }

  createeducation():FormGroup{
    return this.fb.group({
      institute: '',
      qualification: ''
    });
  }

  addEducation() {
    this.userForm.controls.education.push(this.createeducation());
  }

}
